from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import SchaefflerItem

import json
import re

class schafflerSpider(CrawlSpider):

    name = "schaffler"

    main_link = "https://www.schaeffler.de/content.schaeffler.de/en/_global/json/haupia/haupia-search-distributorslocations.jsp?resultsToShow=30&page=swap_page&startHit=swap_hit&sort_by=name&searchString=&filter=brand:fag"


    def __init__(self, *args, **kwargs):                    
        super(schafflerSpider, self).__init__(*args, **kwargs)
        pass              
  

    def start_requests(self,file=None):

        hit = 0

        for page_number in range(1,122):

            temp_link = self.main_link
            temp_link = temp_link.replace("swap_page",str(page_number))
            temp_link = temp_link.replace("swap_hit",str(hit))

            yield Request(url= temp_link,callback=self.page)       
            
            hit += 30

        

    def page(self, response):

        info = json.loads(response.text)

        for data in info["results"]:

            product = SchaefflerItem()

            
            try:
                product["company"] = data["name"]
            except:
                product["company"]  = None

            
            try:
                product["address"] = data["address"]["street"]
            except:
                product["address"] = None

            
            try:
                product["fax"] = data["contact"]["fax"]
            except:
                product["fax"] =  None

            
            try:
                product["city"] = []
                product["city"].append(data["address"]["city"])

                try:

                    product["zip"] = [re.findall(r'(\d+)', s) for s in product["city"]]

                    product["zip"] = " ".join(product["zip"][0])

                    product["city"] = " ".join( product["city"])
                    product["city"] = product["city"].replace(product["zip"] ," ")
                except:
                    product["zip"] = None
            except:
                product["city"] = None
                product["zip"] = None
            
            try:
                product["country"] = data["address"]["country"]
            except:
                product["country"] =  None

            
            try:
                product["phone"] = data["contact"]["phone"]
            except:
                product["phone"] = None

            
            try:
                product["email"] = data["contact"]["mail"]
            except:
                product["email"] = None

            try:
                product["website"] = data["contact"]["weburl"]
            except:
                product["website"] = None

            yield product

